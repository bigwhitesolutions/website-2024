export type Values<T> = T[keyof T];
