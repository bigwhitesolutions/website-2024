/* eslint-disable import/no-extraneous-dependencies, global-require */
module.exports = {
  plugins: [
    require('@tailwindcss/aspect-ratio'),
    require('@tailwindcss/typography'),
  ],
};
